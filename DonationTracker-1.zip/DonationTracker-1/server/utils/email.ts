import { formatCurrency, formatDate } from "../../client/src/lib/utils";

interface EmailReceiptParams {
  to: string;
  receiptNumber: string;
  donationDate: Date;
  name: string;
  amount: number;
  paymentMethod: string;
  transactionId: string;
}

/**
 * Send donation receipt via email
 * This is a mock implementation that logs the email content to the console
 * In a real application, you'd use a library like Nodemailer to send emails
 */
export async function sendEmailReceipt(params: EmailReceiptParams): Promise<void> {
  const {
    to,
    receiptNumber,
    donationDate,
    name,
    amount,
    paymentMethod,
    transactionId,
  } = params;

  // Create email content
  const subject = `Donation Receipt - Om Sri Sarguru Palani Swamigal Trust`;
  
  const emailContent = `
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; color: #333; line-height: 1.6; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { text-align: center; padding: 20px 0; border-bottom: 1px solid #eee; }
          .receipt { background-color: #f9f9f9; border: 1px solid #eee; padding: 20px; margin: 20px 0; }
          .receipt-row { display: flex; justify-content: space-between; margin-bottom: 10px; }
          .footer { text-align: center; margin-top: 30px; font-size: 12px; color: #666; }
          .amount { font-size: 18px; font-weight: bold; }
          .trust-name { color: #1e40af; font-size: 20px; font-weight: bold; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="trust-name">Om Sri Sarguru Palani Swamigal Trust</div>
            <div>Donation Receipt</div>
          </div>
          
          <p>Dear ${name},</p>
          
          <p>Thank you for your generous donation to Om Sri Sarguru Palani Swamigal Trust. 
             Your contribution will help us continue our charitable activities.</p>
          
          <div class="receipt">
            <div class="receipt-row">
              <span>Receipt Number:</span>
              <span>${receiptNumber}</span>
            </div>
            <div class="receipt-row">
              <span>Date & Time:</span>
              <span>${formatDate(donationDate)}</span>
            </div>
            <div class="receipt-row">
              <span>Name:</span>
              <span>${name}</span>
            </div>
            <div class="receipt-row">
              <span>Payment Method:</span>
              <span>${paymentMethod.toUpperCase()}</span>
            </div>
            <div class="receipt-row">
              <span>Transaction ID:</span>
              <span>${transactionId}</span>
            </div>
            <div class="receipt-row" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee;">
              <span>Donation Amount:</span>
              <span class="amount">${formatCurrency(amount)}</span>
            </div>
          </div>
          
          <p>
            If you have any questions about your donation, please contact us at 
            <a href="mailto:contact@sriguruswamitrust.org">contact@sriguruswamitrust.org</a>.
          </p>
          
          <div class="footer">
            <p>Om Sri Sarguru Palani Swamigal Trust</p>
            <p>Kanakkanpatti, Tamil Nadu, India</p>
            <p>&copy; ${new Date().getFullYear()} All rights reserved</p>
          </div>
        </div>
      </body>
    </html>
  `;

  // In a real application, you would send the email using Nodemailer or a similar library
  // For this example, we'll just log the email details to the console
  console.log(`------------ EMAIL RECEIPT ------------`);
  console.log(`To: ${to}`);
  console.log(`Subject: ${subject}`);
  console.log(`Receipt Number: ${receiptNumber}`);
  console.log(`Amount: ${formatCurrency(amount)}`);
  console.log(`----------------------------------`);

  // Simulate a delay for sending the email
  await new Promise(resolve => setTimeout(resolve, 500));

  return Promise.resolve();
}
