import express, { type Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { z } from "zod";
import { ZodError } from "zod";
import { storage } from "./storage";
import { sendEmailReceipt } from "./utils/email";
import { formatCurrency, formatDate, generateReceiptNumber, generateTransactionId } from "../client/src/lib/utils";
import { generateOTP, sendOTP, calculateOtpExpiryTime } from "../client/src/lib/otp";
import {
  loginSchema,
  verifyOtpSchema,
  registrationSchema,
  paymentSchema,
} from "../shared/schema";

// Add type definitions for Express Request with files
declare global {
  namespace Express {
    interface Request {
      files?: {
        [fieldname: string]: Multer.File[];
      };
    }
  }
}

// Configure multer storage for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 2 * 1024 * 1024, // 2MB limit
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // API error handler middleware
  const handleApiError = (err: any, req: Request, res: Response) => {
    console.error("API Error:", err);

    if (err instanceof ZodError) {
      return res.status(400).json({
        message: "Validation error",
        errors: err.errors,
      });
    }

    const status = err.status || 500;
    const message = err.message || "Internal server error";

    return res.status(status).json({ message });
  };

  // Authentication routes
  app.post("/api/auth/send-otp", async (req: Request, res: Response) => {
    try {
      console.log("Received send-otp request:", req.body);
      const result = loginSchema.safeParse(req.body);
      
      if (!result.success) {
        console.error("OTP validation error:", result.error);
        return res.status(400).json({ message: "Invalid mobile number format", errors: result.error.errors });
      }
      
      const { mobileNumber } = result.data;
      console.log("Parsed mobile number:", mobileNumber);
      
      // Generate a 6-digit OTP
      const otp = generateOTP(6);
      const expiresAt = calculateOtpExpiryTime();
      
      // Store OTP in the database
      await storage.saveOTP({
        mobileNumber,
        otp,
        expiresAt,
      });
      
      // Send OTP via SMS (mock implementation)
      await sendOTP(mobileNumber, otp);
      
      res.status(200).json({ message: "OTP sent successfully" });
    } catch (error) {
      console.error("Error sending OTP:", error);
      handleApiError(error, req, res);
    }
  });

  app.post("/api/auth/verify-otp", async (req: Request, res: Response) => {
    try {
      console.log("Received verify-otp request:", req.body);
      
      const result = verifyOtpSchema.safeParse(req.body);
      if (!result.success) {
        console.error("OTP validation error:", result.error);
        return res.status(400).json({ message: "Invalid input data", errors: result.error.errors });
      }
      
      const { mobileNumber, otp } = result.data;
      console.log(`Verifying OTP for ${mobileNumber}. Received OTP: ${otp}`);
      
      // Master OTP for testing purposes
      const MASTER_OTP = "123456";
      let isValid = false;
      
      // Check if it's the master OTP
      if (otp === MASTER_OTP) {
        console.log("Master OTP used - bypassing verification");
        isValid = true;
      } else {
        // Verify against saved OTP
        isValid = await storage.verifyOTP(mobileNumber, otp);
        console.log(`OTP verification result: ${isValid ? 'Valid' : 'Invalid'}`);
      }
      
      if (!isValid) {
        console.log("OTP verification failed");
        return res.status(400).json({ message: "Invalid or expired OTP" });
      }
      
      // Check if user exists
      const user = await storage.getUserByMobileNumber(mobileNumber);
      const userExists = !!user;
      console.log(`User exists: ${userExists}. User ID: ${user?.id || 'N/A'}`);
      
      res.status(200).json({ 
        message: "OTP verified successfully",
        userExists,
        userId: user?.id
      });
    } catch (error) {
      console.error("OTP verification error:", error);
      handleApiError(error, req, res);
    }
  });

  // User routes
  app.post("/api/users/register", async (req: Request, res: Response) => {
    try {
      const userData = registrationSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByMobileNumber(userData.mobileNumber);
      
      if (existingUser) {
        return res.status(400).json({ message: "User with this mobile number already exists" });
      }
      
      // Create new user
      const user = await storage.createUser(userData);
      
      res.status(201).json(user);
    } catch (error) {
      handleApiError(error, req, res);
    }
  });

  app.get("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.status(200).json(user);
    } catch (error) {
      handleApiError(error, req, res);
    }
  });

  // Payment routes
  app.post("/api/payments/process", upload.fields([
    { name: 'aadharDoc', maxCount: 1 },
    { name: 'panDoc', maxCount: 1 }
  ]), async (req: Request, res: Response) => {
    try {
      // Extract files if they exist
      const files = req.files as { [fieldname: string]: Express.Multer.File[] } | undefined;
      
      // Validate core payment data
      let donationPurpose = req.body.donationPurpose;
      const customDonationPurpose = req.body.customDonationPurpose;
      
      // Use custom donation purpose for general donations if provided
      if (donationPurpose === 'general' && customDonationPurpose) {
        donationPurpose = customDonationPurpose;
      }
      
      const paymentData = {
        userId: parseInt(req.body.userId),
        amount: parseInt(req.body.amount),
        paymentMethod: req.body.paymentMethod,
        donationPurpose: donationPurpose,
        taxExemption: req.body.taxExemption === 'yes',
        aadharNumber: req.body.aadharNumber,
        panNumber: req.body.panNumber,
      };

      // Validate the core payment data
      paymentSchema.parse(paymentData);
      
      // Check if user exists
      const user = await storage.getUser(paymentData.userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Generate receipt number and transaction ID
      const receiptNumber = generateReceiptNumber();
      const transactionId = generateTransactionId(paymentData.paymentMethod);
      
      // Process file paths (in a real app, you'd save these files to storage)
      let aadharDocPath = null;
      let panDocPath = null;
      
      if (paymentData.taxExemption && files) {
        if (files.aadharDoc && files.aadharDoc[0]) {
          // In a real app, store the file and get its path
          aadharDocPath = `uploads/aadhar/${user.id}_${Date.now()}.${files.aadharDoc[0].originalname.split('.').pop()}`;
        }
        
        if (files.panDoc && files.panDoc[0]) {
          // In a real app, store the file and get its path
          panDocPath = `uploads/pan/${user.id}_${Date.now()}.${files.panDoc[0].originalname.split('.').pop()}`;
        }
      }
      
      // Create donation record
      const donation = await storage.createDonation({
        userId: paymentData.userId,
        amount: paymentData.amount,
        paymentMethod: paymentData.paymentMethod,
        donationPurpose: paymentData.donationPurpose,
        transactionId,
        taxExemption: paymentData.taxExemption,
        aadharNumber: paymentData.taxExemption ? paymentData.aadharNumber : null,
        panNumber: paymentData.taxExemption ? paymentData.panNumber : null,
        aadharDocPath,
        panDocPath,
        receiptNumber,
      });
      
      // Send email receipt
      await sendEmailReceipt({
        to: user.email,
        receiptNumber,
        donationDate: new Date(),
        name: `${user.firstName} ${user.lastName}`,
        amount: paymentData.amount,
        paymentMethod: paymentData.paymentMethod,
        transactionId,
      });
      
      res.status(200).json({
        id: donation.id,
        receiptNumber,
        transactionId,
        donationDate: donation.donationDate,
        message: "Payment processed successfully",
      });
    } catch (error) {
      handleApiError(error, req, res);
    }
  });

  // Receipt route
  app.get("/api/receipts/:receiptNumber", async (req: Request, res: Response) => {
    try {
      const { receiptNumber } = req.params;
      
      const donation = await storage.getDonationByReceiptNumber(receiptNumber);
      
      if (!donation) {
        return res.status(404).json({ message: "Receipt not found" });
      }
      
      res.status(200).json(donation);
    } catch (error) {
      handleApiError(error, req, res);
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
