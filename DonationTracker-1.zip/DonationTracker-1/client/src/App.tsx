import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { DonationProvider } from "@/lib/context";

import Login from "@/pages/login";
import Registration from "@/pages/registration";
import Payment from "@/pages/payment";
import Receipt from "@/pages/receipt";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Login} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Registration} />
      <Route path="/payment" component={Payment} />
      <Route path="/receipt" component={Receipt} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <DonationProvider>
        <Router />
        <Toaster />
      </DonationProvider>
    </QueryClientProvider>
  );
}

export default App;
