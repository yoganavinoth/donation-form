import * as React from "react";
import { useState } from "react";
import { Upload, FileType, Check, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "type" | "value" | "onChange"> {
  icon?: React.ReactNode;
  fileType?: string;
  onFileChange?: (file: File | null) => void;
  value?: File | null;
  error?: string;
}

const FileInput = React.forwardRef<HTMLInputElement, FileInputProps>(
  ({ className, fileType = "PNG, JPG, or PDF up to 2MB", icon, onFileChange, value, error, ...props }, ref) => {
    const [file, setFile] = useState<File | null>(value || null);
    const [isDragging, setIsDragging] = useState(false);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const selectedFile = e.target.files?.[0] || null;
      setFile(selectedFile);
      if (onFileChange) {
        onFileChange(selectedFile);
      }
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      setIsDragging(true);
    };

    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      setIsDragging(false);
    };

    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      setIsDragging(false);
      const droppedFile = e.dataTransfer.files?.[0] || null;
      setFile(droppedFile);
      if (onFileChange) {
        onFileChange(droppedFile);
      }
    };

    return (
      <div className={cn("relative", className)}>
        <div
          className={cn(
            "mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-md transition-colors",
            isDragging ? "border-primary bg-primary/5" : "border-gray-300",
            error ? "border-red-300" : ""
          )}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <div className="space-y-1 text-center">
            {file ? (
              <div className="flex flex-col items-center">
                <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center mb-2">
                  <Check className="h-6 w-6 text-green-600" />
                </div>
                <p className="text-sm text-gray-700 font-medium">{file.name}</p>
                <p className="text-xs text-gray-500">
                  {(file.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            ) : (
              <>
                <div className="flex justify-center">
                  {icon || <Upload className="h-10 w-10 text-gray-400" />}
                </div>
                <div className="flex text-sm text-gray-600">
                  <label
                    htmlFor={props.id}
                    className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-primary/80"
                  >
                    <span>Upload a file</span>
                    <input
                      id={props.id}
                      ref={ref}
                      type="file"
                      accept=".jpg,.jpeg,.png,.pdf"
                      className="sr-only"
                      onChange={handleFileChange}
                      {...props}
                    />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs text-gray-500">{fileType}</p>
              </>
            )}
          </div>
        </div>
        {error && (
          <div className="flex items-center mt-1 text-red-500 text-xs">
            <AlertCircle className="h-3 w-3 mr-1" />
            <span>{error}</span>
          </div>
        )}
      </div>
    );
  }
);

FileInput.displayName = "FileInput";

export { FileInput };
