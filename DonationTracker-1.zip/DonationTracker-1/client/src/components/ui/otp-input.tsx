import * as React from "react";
import { useRef, useEffect, useState, KeyboardEvent } from "react";
import { cn } from "@/lib/utils";

// Create a custom interface without extending HTMLAttributes to avoid type conflicts
interface OtpInputProps {
  length?: number;
  value?: string;
  onChange?: (otp: string) => void;
  error?: string;
  className?: string;
}

export const OtpInput = React.forwardRef<HTMLDivElement, OtpInputProps>(
  ({ className, length = 6, value = "", onChange, error, ...props }, ref) => {
    const [otp, setOtp] = useState<string[]>(() => {
      // Initialize with the correct array length
      const valueChars = value ? value.split("").slice(0, length) : [];
      const emptySlots = Array(Math.max(0, length - valueChars.length)).fill("");
      return [...valueChars, ...emptySlots];
    });
    
    const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

    // Initialize inputRefs array with the correct length
    useEffect(() => {
      inputRefs.current = inputRefs.current.slice(0, length);
      while (inputRefs.current.length < length) {
        inputRefs.current.push(null);
      }
    }, [length]);

    const focusInput = (index: number) => {
      if (index >= 0 && index < length && inputRefs.current[index]) {
        inputRefs.current[index]?.focus();
      }
    };

    useEffect(() => {
      // If value prop changes externally, update internal state
      if (value !== undefined) {
        console.log("OtpInput: value prop changed:", value);
        const valueChars = value.split("").slice(0, length);
        const emptySlots = Array(Math.max(0, length - valueChars.length)).fill("");
        setOtp([...valueChars, ...emptySlots]);
      }
    }, [value, length]);

    useEffect(() => {
      // Focus first input on mount if empty
      if (!value && inputRefs.current[0]) {
        inputRefs.current[0]?.focus();
      }
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
      const newValue = e.target.value;
      if (newValue.length > 1) {
        // Handle paste event
        const pastedValues = newValue.split("").slice(0, length - index);
        const newOtp = [...otp];
        
        pastedValues.forEach((char, i) => {
          if (index + i < length) {
            newOtp[index + i] = char;
          }
        });

        setOtp(newOtp);
        const nextFocusIndex = Math.min(index + pastedValues.length, length - 1);
        focusInput(nextFocusIndex);
        
        if (onChange) {
          onChange(newOtp.join(""));
        }
        return;
      }

      // Handle single character input
      if (/^[0-9]$/.test(newValue) || newValue === "") {
        const newOtp = [...otp];
        newOtp[index] = newValue;
        setOtp(newOtp);

        if (newValue !== "" && index < length - 1) {
          focusInput(index + 1);
        }

        if (onChange) {
          onChange(newOtp.join(""));
        }
      }
    };

    const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>, index: number) => {
      if (e.key === "Backspace") {
        if (otp[index] === "" && index > 0) {
          focusInput(index - 1);
          const newOtp = [...otp];
          newOtp[index - 1] = "";
          setOtp(newOtp);
          
          if (onChange) {
            onChange(newOtp.join(""));
          }
        }
      } else if (e.key === "ArrowLeft" && index > 0) {
        focusInput(index - 1);
      } else if (e.key === "ArrowRight" && index < length - 1) {
        focusInput(index + 1);
      }
    };

    // Handle direct OTP entry for testing
    const handleSetMasterOtp = () => {
      const masterOtp = "123456";
      const valueChars = masterOtp.split("").slice(0, length);
      const newOtp = [...valueChars];
      
      setOtp(newOtp);
      
      if (onChange) {
        onChange(masterOtp);
      }
    };
    
    return (
      <div ref={ref} className={cn("flex flex-col space-y-4", className)} {...props}>
        <div className="flex justify-center gap-2">
          {Array.from({ length }, (_, index) => (
            <input
              key={index}
              ref={(el) => {
                inputRefs.current[index] = el;
              }}
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={1}
              value={otp[index] || ""}
              onChange={(e) => handleChange(e, index)}
              onKeyDown={(e) => handleKeyDown(e, index)}
              className={cn(
                "w-10 h-12 text-center border rounded-md focus:ring-2 focus:ring-primary focus:border-primary text-lg font-medium",
                error ? "border-red-300 focus:ring-red-500 focus:border-red-500" : "border-gray-300"
              )}
              autoComplete="one-time-code"
              required
            />
          ))}
        </div>
        <button 
          type="button"
          onClick={handleSetMasterOtp}
          className="text-primary text-xs font-semibold mx-auto block"
        >
          Use Master OTP (123456)
        </button>
        {error && <p className="text-xs text-red-500 text-center">{error}</p>}
      </div>
    );
  }
);
