import { cn } from "@/lib/utils";

interface StepIndicatorProps {
  currentStep: number;
  steps: { label: string }[];
  className?: string;
}

export function StepIndicator({ currentStep, steps, className }: StepIndicatorProps) {
  // Convert steps to flattened elements with proper keys
  const elements = [];
  
  for (let index = 0; index < steps.length; index++) {
    const step = steps[index];
    
    // Add the step circle and label
    elements.push(
      <div key={`step-${index}`} className="flex flex-col items-center">
        <div
          className={cn(
            "w-8 h-8 rounded-full border-2 flex items-center justify-center font-semibold text-sm mb-1",
            index < currentStep
              ? "bg-primary text-white border-primary" // completed
              : index === currentStep
              ? "text-primary border-primary" // active
              : "text-gray-400 border-gray-300" // inactive
          )}
        >
          {index + 1}
        </div>
        <span
          className={cn(
            "text-xs font-medium",
            index < currentStep || index === currentStep
              ? "text-primary"
              : "text-gray-400"
          )}
        >
          {step.label}
        </span>
      </div>
    );
    
    // Add the line connector if not the last step
    if (index < steps.length - 1) {
      elements.push(
        <div
          key={`connector-${index}`}
          className={cn(
            "flex-grow mx-2 h-0.5",
            index < currentStep
              ? "bg-primary" // completed
              : "bg-gray-300" // inactive
          )}
        />
      );
    }
  }
  
  return (
    <div className={cn("flex items-center justify-between w-full", className)}>
      {elements}
    </div>
  );
}
