import { ReactNode } from "react";
import { StepIndicator } from "./step-indicator";
import swamigalImage from "@assets/Kanakkanpatti-Mootai-Swamigal-0.jpeg";

interface DonationLayoutProps {
  children: ReactNode;
  currentStep: number;
}

export function DonationLayout({ children, currentStep }: DonationLayoutProps) {
  const steps = [
    { label: "Login" },
    { label: "Details" },
    { label: "Payment" },
    { label: "Receipt" },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center">
            {/* Logo - Swamigal Image */}
            <div className="w-16 h-16 rounded-full overflow-hidden mr-3 border-2 border-primary">
              <img 
                src={swamigalImage} 
                alt="Om Sri Sarguru Palani Swamigal" 
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h1 className="font-heading font-bold text-lg md:text-xl text-primary">
                Om Sri Sarguru Palani Swamigal Trust
              </h1>
              <p className="text-xs text-gray-600">Donation Portal</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow container mx-auto px-4 py-8">
        {/* Step indicator */}
        <div className="max-w-xl mx-auto mb-8">
          <StepIndicator 
            currentStep={currentStep} 
            steps={steps} 
          />
        </div>

        {/* Form container */}
        <div className="max-w-xl mx-auto bg-white rounded-lg shadow-md p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
