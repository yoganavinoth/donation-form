import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  console.log(`API Request: ${method} ${url}`, data);
  
  try {
    const res = await fetch(url, {
      method,
      headers: data ? { "Content-Type": "application/json" } : {},
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
    });

    console.log(`API Response received: ${method} ${url}`, {
      status: res.status,
      statusText: res.statusText,
      headers: Object.fromEntries(res.headers.entries()),
    });

    // Clone the response before checking if it's OK
    // This prevents the response body from being consumed
    const resClone = res.clone();
    
    try {
      await throwIfResNotOk(resClone);
      console.log(`API Response OK: ${method} ${url}`, res.status);
      return res;
    } catch (error) {
      console.error(`API Error: ${method} ${url}`, error);
      
      // Try to read the response body for more debugging info
      try {
        const errorBody = await res.clone().text();
        console.error(`Error response body:`, errorBody);
      } catch (e) {
        console.error(`Could not read error response body:`, e);
      }
      
      throw error;
    }
  } catch (error) {
    console.error(`Network error for ${method} ${url}:`, error);
    // Handle the error safely, ensuring we don't try to access properties that might not exist
    const errorMessage = error instanceof Error ? error.message : 'Unknown network error';
    throw new Error(`Network error: ${errorMessage}`);
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
