import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', { 
    style: 'currency', 
    currency: 'INR',
    maximumFractionDigits: 2,
    minimumFractionDigits: 2 
  }).format(amount);
}

export function generateReceiptNumber(): string {
  const prefix = 'DT';
  const year = new Date().getFullYear().toString().slice(2);
  const month = (new Date().getMonth() + 1).toString().padStart(2, '0');
  const randomDigits = Math.floor(Math.random() * 100000).toString().padStart(5, '0');
  
  return `${prefix}${year}${month}${randomDigits}`;
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  }).format(date);
}

export function generateTransactionId(method: string): string {
  const prefix = method.toUpperCase();
  const timestamp = Date.now().toString().slice(-8);
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  
  return `${prefix}${timestamp}${random}`;
}

// Removed predefined donation amounts as per client request
export const quickDonationAmounts: { label: string; value: number }[] = [];

export function createDownloadLink(content: string, filename: string): void {
  const element = document.createElement('a');
  const file = new Blob([content], {type: 'text/plain'});
  element.href = URL.createObjectURL(file);
  element.download = filename;
  document.body.appendChild(element);
  element.click();
  document.body.removeChild(element);
}

export function shareReceipt(receiptData: any): void {
  if (navigator.share) {
    navigator.share({
      title: 'Donation Receipt - Om Sri Sarguru Palani Swamigal Trust',
      text: `Receipt number: ${receiptData.receiptNumber}\nAmount: ${formatCurrency(receiptData.amount)}\nDate: ${formatDate(new Date(receiptData.donationDate))}`,
      url: window.location.href,
    })
    .catch(err => {
      console.error('Error sharing receipt:', err);
    });
  } else {
    // Fallback for browsers that don't support the Web Share API
    alert('Share functionality is not supported on this browser. You can download the receipt instead.');
  }
}

// Generate PDF receipt from HTML element
export async function generatePDFReceipt(elementId: string, filename: string): Promise<void> {
  try {
    // Wait for UI to update
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // Get the HTML element
    const element = document.getElementById(elementId);
    if (!element) {
      console.error('Element not found:', elementId);
      return;
    }
    
    console.log('Generating PDF from element:', elementId);
    
    // Create canvas from HTML element
    const canvas = await html2canvas(element, {
      scale: 2, // Higher scale for better quality
      logging: false,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff'
    });
    
    // Canvas dimensions
    const imgWidth = 210; // A4 width in mm (210mm × 297mm)
    const pageHeight = 297; // A4 height in mm
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    
    // Initialize PDF document
    const pdf = new jsPDF('p', 'mm', 'a4');
    
    // Add image to PDF
    const imgData = canvas.toDataURL('image/png');
    pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
    
    // Save the PDF
    pdf.save(filename);
    console.log('PDF generated successfully:', filename);
    
  } catch (error) {
    console.error('Error generating PDF:', error);
  }
}
