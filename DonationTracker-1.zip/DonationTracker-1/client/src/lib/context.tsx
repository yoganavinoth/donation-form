import { createContext, useContext, useState, ReactNode } from "react";

interface DonationDetailsType {
  id: number;
  amount: number;
  receiptNumber: string;
  paymentMethod: string;
  donationPurpose?: string;
  transactionId: string;
  donationDate: string;
}

interface DonationContextType {
  userId: number | null;
  setUserId: (id: number) => void;
  userMobile: string | null;
  setUserMobile: (mobile: string) => void;
  donationDetails: DonationDetailsType | null;
  setDonationDetails: (details: DonationDetailsType) => void;
  resetContext: () => void;
}

const DonationContext = createContext<DonationContextType | undefined>(undefined);

export function DonationProvider({ children }: { children: ReactNode }) {
  const [userId, setUserId] = useState<number | null>(null);
  const [userMobile, setUserMobile] = useState<string | null>(null);
  const [donationDetails, setDonationDetails] = useState<DonationDetailsType | null>(null);

  const resetContext = () => {
    setUserId(null);
    setUserMobile(null);
    setDonationDetails(null);
  };

  return (
    <DonationContext.Provider
      value={{
        userId,
        setUserId,
        userMobile,
        setUserMobile,
        donationDetails,
        setDonationDetails,
        resetContext,
      }}
    >
      {children}
    </DonationContext.Provider>
  );
}

export function useDonationContext() {
  const context = useContext(DonationContext);
  if (context === undefined) {
    throw new Error("useDonationContext must be used within a DonationProvider");
  }
  return context;
}
