/**
 * Generate a random OTP of specified length
 * @param length Length of the OTP
 * @returns Random OTP string
 */
export function generateOTP(length: number = 6): string {
  const digits = '0123456789';
  let otp = '';
  
  for (let i = 0; i < length; i++) {
    otp += digits[Math.floor(Math.random() * digits.length)];
  }
  
  return otp;
}

/**
 * Mock function to send OTP via SMS (in production, this would be replaced with a real SMS gateway)
 * @param mobileNumber Mobile number to send OTP to
 * @param otp OTP to send
 * @returns Promise resolving to success message
 */
export async function sendOTP(mobileNumber: string, otp: string): Promise<string> {
  // This is a mock implementation. In a real app, this would integrate with an SMS gateway.
  console.log(`Sending OTP ${otp} to ${mobileNumber}`);
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // In development, always return success
  return `OTP sent successfully to ${mobileNumber}`;
}

/**
 * Calculate OTP expiration time (5 minutes from now)
 * @returns Date object 5 minutes in the future
 */
export function calculateOtpExpiryTime(): Date {
  const expiryTime = new Date();
  expiryTime.setMinutes(expiryTime.getMinutes() + 5); // OTP valid for 5 minutes
  return expiryTime;
}
