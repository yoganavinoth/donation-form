import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { useEffect } from "react";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { DonationLayout } from "@/components/donation-layout";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import swamigalImage from "@assets/Kanakkanpatti-Mootai-Swamigal-0.jpeg";
import { useDonationContext } from "@/lib/context";
import { registrationSchema } from "@shared/schema";
import type { RegistrationRequest } from "@shared/schema";

const states = [
  { value: "TN", label: "Tamil Nadu" },
  { value: "KL", label: "Kerala" },
  { value: "KA", label: "Karnataka" },
  { value: "AP", label: "Andhra Pradesh" },
  { value: "TG", label: "Telangana" },
  { value: "MH", label: "Maharashtra" },
  { value: "GJ", label: "Gujarat" },
  { value: "DL", label: "Delhi" },
];

export default function Registration() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { userMobile, setUserId } = useDonationContext();
  
  // Use useEffect for navigation to avoid React update during render error
  useEffect(() => {
    console.log("Registration - userMobile value:", userMobile);
    if (!userMobile) {
      console.log("No mobile number found in context, redirecting to login");
      toast({
        title: "உள்நுழைவு தேவை / Login Required",
        description: "உங்கள் மொபைல் எண்ணை உறுதிப்படுத்த முதலில் உள்நுழைய வேண்டும் / Please login first to verify your mobile number",
        variant: "destructive"
      });
      navigate("/login");
    } else {
      console.log("Mobile number found in context:", userMobile);
    }
  }, [userMobile, navigate, toast]);
  
  // Return loading state if no mobile
  if (!userMobile) {
    return <div className="flex items-center justify-center h-screen">Redirecting to login...</div>;
  }

  const form = useForm<RegistrationRequest>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      mobileNumber: userMobile,
      email: "",
      dob: "",
      doorNo: "",
      street: "",
      taluk: "",
      city: "",
      village: "",
      pincode: "",
      state: "",
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: RegistrationRequest) => {
      const response = await apiRequest("POST", "/api/users/register", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Registration Successful",
        description: "Your details have been saved successfully.",
      });
      
      // Store user ID in context
      setUserId(data.id);
      
      // Navigate to payment page
      navigate("/payment");
    },
    onError: (error) => {
      toast({
        title: "Registration Failed",
        description: error.message || "An error occurred during registration. Please try again.",
        variant: "destructive",
      });
    },
  });

  function onSubmit(values: RegistrationRequest) {
    registerMutation.mutate(values);
  }

  return (
    <DonationLayout currentStep={1}>
      <div className="mb-6 text-center">
        <div className="w-24 h-24 mx-auto mb-4 rounded-full overflow-hidden border-2 border-primary">
          <img 
            src={swamigalImage} 
            alt="Om Sri Sarguru Palani Swamigal" 
            className="w-full h-full object-cover"
          />
        </div>
        <h2 className="text-xl font-heading font-semibold text-primary-800 mb-2">
          Personal Details
        </h2>
        <p className="text-sm text-gray-600">
          Please provide your information for the donation
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="firstName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>First Name*</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter first name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="lastName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Last Name*</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter last name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="mobileNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Mobile Number*</FormLabel>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <span className="text-gray-500">+91</span>
                    </div>
                    <FormControl>
                      <Input
                        type="tel"
                        placeholder="Enter mobile number"
                        className="pl-12"
                        {...field}
                        disabled
                      />
                    </FormControl>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email*</FormLabel>
                  <FormControl>
                    <Input 
                      type="email" 
                      placeholder="Enter email address" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="dob"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Date of Birth*</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="border-t border-gray-200 pt-4">
            <h3 className="text-lg font-heading font-medium text-gray-800 mb-3">
              Address Information
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="doorNo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Door No / Building*</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter door number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="street"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Street*</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter street name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <FormField
                control={form.control}
                name="taluk"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Taluk*</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter taluk" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="village"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Village/Location*</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter village or location" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <FormField
                control={form.control}
                name="city"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>City/District*</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter city or district" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="state"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>State*</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select State" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {states.map((state) => (
                          <SelectItem key={state.value} value={state.value}>
                            {state.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 gap-4 mt-4">
              <FormField
                control={form.control}
                name="pincode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Pincode*</FormLabel>
                    <FormControl>
                      <Input
                        type="text"
                        placeholder="Enter pincode"
                        maxLength={6}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>

          <div className="flex justify-end pt-4">
            <Button 
              type="submit" 
              className="py-6 bg-green-600 hover:bg-green-700 text-white text-lg font-medium"
              disabled={registerMutation.isPending}
            >
              {registerMutation.isPending ? "Saving..." : "Continue to Payment"}
            </Button>
          </div>
        </form>
      </Form>
    </DonationLayout>
  );
}
