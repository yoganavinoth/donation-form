import { useLocation } from "wouter";
import { Check, FileDown, Share } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DonationLayout } from "@/components/donation-layout";
import { useDonationContext } from "@/lib/context";
import { 
  formatCurrency, 
  formatDate, 
  createDownloadLink, 
  shareReceipt, 
  generatePDFReceipt 
} from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useRef } from "react";
import type { User, Donation } from "../../../shared/schema";
import swamigalImage from "@assets/Kanakkanpatti-Mootai-Swamigal-0.jpeg";

export default function Receipt() {
  const [, navigate] = useLocation();
  const { donationDetails, userId } = useDonationContext();
  const { toast } = useToast();
  const receiptRef = useRef<HTMLDivElement>(null);
  
  // Debug output
  console.log("Receipt page loaded with context:", { donationDetails, userId });
  
  // Redirect if no donation details
  if (!donationDetails || !userId) {
    console.log("Missing donation details or userId, redirecting to login", { donationDetails, userId });
    setTimeout(() => {
      navigate("/login");
    }, 0);
    return <div className="flex items-center justify-center h-screen">Redirecting to login...</div>;
  }
  
  // Fetch user data
  const { data: userData, isLoading: userLoading } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
    refetchOnWindowFocus: false,
  });
  
  // Fetch receipt data
  const { data: receiptData, isLoading: receiptLoading } = useQuery<Donation>({
    queryKey: [`/api/receipts/${donationDetails.receiptNumber}`],
    refetchOnWindowFocus: false,
  });
  
  console.log("Receipt data:", receiptData, "User data:", userData);
  
  const isLoading = userLoading || receiptLoading;
  
  // Handle download receipt
  const handleDownloadReceipt = () => {
    if (!userData || !receiptData) return;
    
    // Create a safer version of the date
    const donationDate = receiptData.donationDate ? 
      new Date(receiptData.donationDate) : 
      new Date();
    
    const receiptContent = `
      ======= DONATION RECEIPT =======
      
      Om Sri Sarguru Palani Swamigal Trust
      
      Receipt Number: ${receiptData.receiptNumber}
      Date & Time: ${formatDate(donationDate)}
      
      Name: ${userData.firstName} ${userData.lastName}
      Mobile: +91 ${userData.mobileNumber}
      Email: ${userData.email}
      
      Payment Method: ${receiptData.paymentMethod.toUpperCase()}
      Transaction ID: ${receiptData.transactionId}
      
      Donation Amount: ${formatCurrency(receiptData.amount)}
      
      Thank you for your generous contribution!
      
      ==============================
    `;
    
    createDownloadLink(receiptContent, `receipt-${receiptData.receiptNumber}.txt`);
  };
  
  // Handle share receipt
  const handleShareReceipt = () => {
    if (!userData || !receiptData) return;
    shareReceipt(receiptData);
  };
  
  // Handle make new donation
  const handleMakeNewDonation = () => {
    navigate("/login");
  };
  
  return (
    <DonationLayout currentStep={3}>
      <div className="text-center mb-8">
        <div className="w-24 h-24 mx-auto mb-3 rounded-full overflow-hidden border-2 border-primary">
          <img 
            src={swamigalImage} 
            alt="Om Sri Sarguru Palani Swamigal" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Check className="h-8 w-8 text-green-500" />
        </div>
        <h2 className="text-2xl font-heading font-semibold text-primary-800 mb-2">
          Donation Successful!
        </h2>
        <p className="text-gray-600">
          Thank you for your generous contribution
        </p>
      </div>

      {isLoading ? (
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : (
        <>
          {/* Start of Printable Receipt Section */}
          <div 
            ref={receiptRef}
            className="bg-white rounded-lg p-6 border border-gray-200 mb-6 receipt-container"
            id="receipt-to-print"
          >
            <div className="text-center mb-4 border-b pb-4">
              <div className="w-16 h-16 mx-auto mb-2 rounded-full overflow-hidden border-2 border-green-500">
                <img 
                  src={swamigalImage} 
                  alt="Om Sri Sarguru Palani Swamigal" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h2 className="text-xl font-bold text-green-700">Om Sri Sarguru Palani Swamigal Trust</h2>
              <p className="text-sm text-gray-500">Donation Receipt</p>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 font-medium">Receipt Number:</span>
                <span className="font-medium">
                  {receiptData?.receiptNumber}
                </span>
              </div>

              <div className="flex justify-between text-sm">
                <span className="text-gray-600 font-medium">Date & Time:</span>
                <span className="font-medium">
                  {receiptData && receiptData.donationDate ? 
                    formatDate(new Date(receiptData.donationDate)) : 
                    formatDate(new Date())}
                </span>
              </div>

              <div className="flex justify-between text-sm">
                <span className="text-gray-600 font-medium">Name:</span>
                <span className="font-medium">
                  {userData && `${userData.firstName} ${userData.lastName}`}
                </span>
              </div>

              <div className="flex justify-between text-sm">
                <span className="text-gray-600 font-medium">Mobile:</span>
                <span className="font-medium">
                  {userData && `+91 ${userData.mobileNumber}`}
                </span>
              </div>

              <div className="flex justify-between text-sm">
                <span className="text-gray-600 font-medium">Email:</span>
                <span className="font-medium">
                  {userData?.email}
                </span>
              </div>

              <div className="flex justify-between text-sm">
                <span className="text-gray-600 font-medium">Payment Method:</span>
                <span className="font-medium">
                  {receiptData?.paymentMethod.toUpperCase()}
                </span>
              </div>

              <div className="flex justify-between text-sm">
                <span className="text-gray-600 font-medium">Transaction ID:</span>
                <span className="font-medium">
                  {receiptData?.transactionId}
                </span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 font-medium">Donation Purpose:</span>
                <span className="font-medium">
                  {receiptData?.donationPurpose ? 
                    receiptData.donationPurpose.charAt(0).toUpperCase() + receiptData.donationPurpose.slice(1) :
                    "General"
                  }
                </span>
              </div>

              <div className="flex justify-between font-medium pt-4 border-t border-gray-200 mt-2">
                <span className="text-gray-800">Donation Amount:</span>
                <span className="text-lg text-green-700">
                  {receiptData && formatCurrency(receiptData.amount)}
                </span>
              </div>
              
              <div className="text-center pt-6 text-sm text-gray-500 italic">
                Thank you for your generous contribution!
              </div>
            </div>
          </div>
          {/* End of Printable Receipt Section */}

          <div className="flex flex-col space-y-4">
            <p className="text-sm text-gray-600 text-center">
              A copy of this receipt has been sent to your email address.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button
                variant="outline"
                className="py-2 px-4 bg-gray-50 hover:bg-gray-100 text-gray-800 border-gray-300"
                onClick={handleDownloadReceipt}
              >
                <FileDown className="h-4 w-4 mr-2" />
                Text Receipt
              </Button>
              
              <Button
                variant="default"
                className="py-2 px-4 bg-green-600 hover:bg-green-700 text-white"
                onClick={() => {
                  if (!receiptData) return;
                  
                  toast({
                    title: "Creating PDF...",
                    description: "Please wait while we generate your receipt.",
                  });
                  
                  generatePDFReceipt('receipt-to-print', `receipt-${receiptData.receiptNumber}.pdf`)
                    .then(() => {
                      toast({
                        title: "Success",
                        description: "Receipt downloaded successfully!",
                      });
                    })
                    .catch((error) => {
                      console.error("PDF generation error:", error);
                      toast({
                        title: "Error",
                        description: "Failed to generate PDF. Please try again.",
                        variant: "destructive",
                      });
                    });
                }}
              >
                <FileDown className="h-4 w-4 mr-2" />
                PDF Receipt
              </Button>

              <Button
                variant="outline"
                className="py-2 px-4 bg-white hover:bg-gray-50 text-primary-800 border-primary-800"
                onClick={handleShareReceipt}
              >
                <Share className="h-4 w-4 mr-2" />
                Share Receipt
              </Button>
            </div>

            <Button
              className="mt-4 py-3 px-6 bg-primary-800 hover:bg-primary-700 text-white mx-auto"
              onClick={handleMakeNewDonation}
            >
              Make Another Donation
            </Button>
          </div>
        </>
      )}
    </DonationLayout>
  );
}
