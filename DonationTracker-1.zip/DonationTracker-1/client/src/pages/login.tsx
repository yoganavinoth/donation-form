import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useState } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { OtpInput } from "@/components/ui/otp-input";
import { DonationLayout } from "@/components/donation-layout";
import { useToast } from "@/hooks/use-toast";
import swamigalImage from "@assets/Kanakkanpatti-Mootai-Swamigal-0.jpeg";
import { apiRequest } from "@/lib/queryClient";
import { useDonationContext } from "@/lib/context";
import { loginSchema, verifyOtpSchema } from "@shared/schema";

type LoginFormValues = z.infer<typeof loginSchema>;
type OtpFormValues = z.infer<typeof verifyOtpSchema>;

export default function Login() {
  const [showOtpForm, setShowOtpForm] = useState(false);
  const [mobileNumber, setMobileNumber] = useState("");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { setUserMobile } = useDonationContext();

  // Login form (mobile number)
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      mobileNumber: "",
    },
  });

  // OTP verification form
  const otpForm = useForm<OtpFormValues>({
    resolver: zodResolver(verifyOtpSchema),
    defaultValues: {
      mobileNumber: "",
      otp: "",
    },
    mode: "onChange" // Enable validation on change
  });

  // Send OTP mutation
  const sendOtpMutation = useMutation({
    mutationFn: async (data: LoginFormValues) => {
      try {
        // Sanitize mobile number (remove spaces, dashes, etc.)
        const sanitizedData = {
          mobileNumber: data.mobileNumber.replace(/\D/g, '')
        };
        console.log("Sending OTP with sanitized mobile:", sanitizedData);
        return apiRequest("POST", "/api/auth/send-otp", sanitizedData);
      } catch (err) {
        console.error("Error in OTP mutation:", err);
        throw err;
      }
    },
    onSuccess: () => {
      toast({
        title: "OTP Sent",
        description: "An OTP has been sent to your mobile number.",
      });
      setShowOtpForm(true);
    },
    onError: (error) => {
      console.error("Send OTP error:", error);
      toast({
        title: "Error",
        description: "Failed to send OTP. Please try again with a valid 10-digit mobile number.",
        variant: "destructive",
      });
    },
  });

  // Verify OTP mutation
  const verifyOtpMutation = useMutation({
    mutationFn: async (data: OtpFormValues) => {
      try {
        // Sanitize mobile number and OTP
        const sanitizedData = {
          mobileNumber: data.mobileNumber.replace(/\D/g, ''),
          otp: data.otp.replace(/\D/g, '')
        };
        console.log("Submitting OTP verification with sanitized data:", sanitizedData);
        const response = await apiRequest("POST", "/api/auth/verify-otp", sanitizedData);
        console.log("API response status:", response.status);
        const jsonData = await response.json();
        console.log("OTP verification response:", jsonData);
        return jsonData;
      } catch (err) {
        console.error("Error in OTP verification:", err);
        throw err;
      }
    },
    onSuccess: (data) => {
      console.log("OTP verification success handler. Data:", data);
      
      toast({
        title: "Success",
        description: "OTP verified successfully",
      });
      
      // Store the mobile number in context
      console.log("Setting user mobile in context:", mobileNumber);
      setUserMobile(mobileNumber);
      
      // Debug log
      console.log(`User exists: ${data.userExists}. Navigating to: ${data.userExists ? "/payment" : "/register"}`);
      
      // Navigate based on whether user exists or not
      if (data.userExists) {
        console.log("User exists, navigating to payment page");
        navigate("/payment");
      } else {
        console.log("New user, navigating to registration page");
        navigate("/register");
      }
    },
    onError: (error) => {
      console.error("OTP verification error:", error);
      toast({
        title: "Error",
        description: error.message || "Invalid OTP. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Handle login form submission
  const onLoginSubmit = (values: LoginFormValues) => {
    // Set the mobile number in state
    const sanitizedMobile = values.mobileNumber.replace(/\D/g, '');
    setMobileNumber(sanitizedMobile);
    
    // Pre-populate the OTP form with the mobile number
    otpForm.setValue("mobileNumber", sanitizedMobile);
    
    // Use master OTP directly instead of showing OTP form
    verifyOtpMutation.mutate({
      mobileNumber: sanitizedMobile,
      otp: "123456" // Use the master OTP directly
    });
  };

  // Manual OTP bypass for testing
  const handleBypassOtp = () => {
    console.log("Using bypass OTP");
    
    verifyOtpMutation.mutate({
      mobileNumber: mobileNumber,
      otp: "123456", // Use the master OTP directly
    });
  };

  // Handle OTP form submission
  const onOtpSubmit = (values: OtpFormValues) => {
    console.log("OTP submission with values:", values);
    console.log("OTP value length:", values.otp ? values.otp.length : 0);
    console.log("Mobile number:", mobileNumber);
    
    // Check if form is valid
    const formErrors = otpForm.formState.errors;
    if (Object.keys(formErrors).length > 0) {
      console.error("Form validation errors:", formErrors);
      return;
    }
    
    // Make sure the OTP is properly formatted
    const sanitizedOtp = values.otp ? values.otp.replace(/\s+/g, '').trim() : '';
    console.log("Sanitized OTP:", sanitizedOtp, "Length:", sanitizedOtp.length);
    
    if (sanitizedOtp.length !== 6) {
      toast({
        title: "Error",
        description: `OTP must be 6 digits. Current length: ${sanitizedOtp.length}`,
        variant: "destructive",
      });
      return;
    }
    
    verifyOtpMutation.mutate({
      mobileNumber: mobileNumber,
      otp: sanitizedOtp,
    });
  };

  // Handle resend OTP
  const handleResendOtp = () => {
    if (mobileNumber) {
      sendOtpMutation.mutate({ mobileNumber });
    }
  };

  return (
    <DonationLayout currentStep={0}>
      {!showOtpForm ? (
        // Mobile number form
        <>
          <div className="text-center mb-8">
            <div className="w-24 h-24 mx-auto mb-4 rounded-full overflow-hidden border-2 border-primary">
              <img 
                src={swamigalImage} 
                alt="Om Sri Sarguru Palani Swamigal" 
                className="w-full h-full object-cover"
              />
            </div>
            <h2 className="text-2xl font-heading font-semibold text-primary-800 mb-2">
              Welcome
            </h2>
            <p className="text-gray-600">
              Enter your mobile number to continue
            </p>
          </div>

          <Form {...loginForm}>
            <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-6">
              <FormField
                control={loginForm.control}
                name="mobileNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mobile Number</FormLabel>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <span className="text-gray-500">+91</span>
                      </div>
                      <FormControl>
                        <Input
                          type="tel"
                          placeholder="Enter 10 digit mobile number"
                          className="pl-12"
                          {...field}
                        />
                      </FormControl>
                    </div>
                    <p className="text-xs text-gray-500">
                      We'll send an OTP to this number
                    </p>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                className="w-full py-6 bg-green-600 hover:bg-green-700 text-white text-lg font-medium" 
                disabled={sendOtpMutation.isPending}
              >
                {sendOtpMutation.isPending ? "Processing..." : "Continue"}
              </Button>
            </form>
          </Form>
        </>
      ) : (
        // OTP verification form
        <>
          <div className="text-center mb-8">
            <div className="w-24 h-24 mx-auto mb-4 rounded-full overflow-hidden border-2 border-primary">
              <img 
                src={swamigalImage} 
                alt="Om Sri Sarguru Palani Swamigal" 
                className="w-full h-full object-cover"
              />
            </div>
            <h2 className="text-2xl font-heading font-semibold text-primary-800 mb-2">
              Verify OTP
            </h2>
            <p className="text-gray-600">
              Enter the verification code sent to your mobile
            </p>
          </div>

          <Form {...otpForm}>
            <form onSubmit={otpForm.handleSubmit(onOtpSubmit)} className="space-y-6">
              <FormField
                control={otpForm.control}
                name="otp"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Enter OTP</FormLabel>
                    <FormControl>
                      <OtpInput
                        length={6}
                        value={field.value}
                        onChange={field.onChange}
                      />
                    </FormControl>
                    <div className="mt-1 text-xs text-gray-500 text-center">
                      OTP sent to +91 {mobileNumber}
                      <button
                        type="button"
                        className="text-primary font-medium ml-1"
                        onClick={handleResendOtp}
                        disabled={sendOtpMutation.isPending}
                      >
                        {sendOtpMutation.isPending ? "Sending..." : "Resend"}
                      </button>
                      <div className="mt-1 text-xs text-green-600 font-semibold">
                        For testing: Use master OTP "123456"
                      </div>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="space-y-2">
                <Button 
                  type="button" 
                  variant="default"
                  className="w-full py-6 text-lg font-medium bg-green-600 hover:bg-green-700"
                  onClick={handleBypassOtp}
                  disabled={verifyOtpMutation.isPending}
                >
                  {verifyOtpMutation.isPending ? "Verifying..." : "Continue with Test Mode"}
                </Button>
                
                <div className="text-center text-sm text-gray-500 mt-2">-- OR --</div>
                
                <Button 
                  type="submit" 
                  className="w-full py-4"
                  variant="outline"
                  disabled={verifyOtpMutation.isPending}
                >
                  Verify with OTP
                </Button>
              </div>
            </form>
          </Form>
        </>
      )}
    </DonationLayout>
  );
}
