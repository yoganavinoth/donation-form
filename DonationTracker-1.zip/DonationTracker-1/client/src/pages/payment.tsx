import { useState, useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { z } from "zod";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { FileInput } from "@/components/ui/file-input";
import swamigalImage from "@assets/Kanakkanpatti-Mootai-Swamigal-0.jpeg";
import { DonationLayout } from "@/components/donation-layout";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useDonationContext } from "@/lib/context";
import { formatCurrency, quickDonationAmounts } from "@/lib/utils";

// Define payment form schema
const paymentFormSchema = z.object({
  taxExemption: z.enum(["yes", "no"]),
  aadharNumber: z.string().optional(),
  panNumber: z.string().optional(),
  donationAmount: z.string().min(1, "Donation amount is required"),
  donationPurpose: z.enum(["medical", "education", "food", "general"]),
  customDonationPurpose: z.string().optional(),
  paymentMethod: z.enum(["upi", "card", "netbanking"]),
});

type PaymentFormValues = z.infer<typeof paymentFormSchema>;

export default function Payment() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { userId, userMobile, setDonationDetails } = useDonationContext();
  const [aadharFile, setAadharFile] = useState<File | null>(null);
  const [panFile, setPanFile] = useState<File | null>(null);
  
  // Use useEffect for navigation to avoid React update during render error
  useEffect(() => {
    if (!userId && !userMobile) {
      navigate("/login");
    }
  }, [userId, userMobile, navigate]);
  
  // Return loading state if not authenticated
  if (!userId && !userMobile) {
    return <div className="flex items-center justify-center h-screen">Redirecting to login...</div>;
  }
  
  // Fetch user data if user ID exists
  const { data: userData } = useQuery({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
  });

  // Form setup
  const form = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentFormSchema),
    defaultValues: {
      taxExemption: "no",
      donationAmount: "1100",
      donationPurpose: "general",
      paymentMethod: "upi",
    },
  });

  // Watch tax exemption field to show/hide document fields
  const taxExemption = form.watch("taxExemption");
  const showTaxDocs = taxExemption === "yes";

  // Process payment mutation
  const processPaymentMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/payments/process', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || response.statusText);
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      console.log("Payment successful, received data:", data);
      toast({
        title: "Payment Successful",
        description: "Your donation has been processed successfully.",
      });
      
      // Store donation details for receipt page
      const donationDetails = {
        id: data.id,
        amount: Number(form.getValues().donationAmount),
        receiptNumber: data.receiptNumber,
        paymentMethod: form.getValues().paymentMethod,
        donationPurpose: form.getValues().donationPurpose === "general" && form.getValues().customDonationPurpose
          ? form.getValues().customDonationPurpose
          : form.getValues().donationPurpose,
        transactionId: data.transactionId,
        donationDate: data.donationDate,
      };
      
      console.log("Setting donation details in context:", donationDetails);
      setDonationDetails(donationDetails);
      
      // Wait a moment for context to update before navigating
      setTimeout(() => {
        // Navigate to receipt page
        console.log("Navigating to receipt page");
        navigate("/receipt");
      }, 300);
    },
    onError: (error) => {
      toast({
        title: "Payment Failed",
        description: error.message || "An error occurred while processing your payment. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  function onSubmit(values: PaymentFormValues) {
    // Validate tax documents if tax exemption is selected
    if (values.taxExemption === "yes") {
      if (!values.aadharNumber || !values.panNumber) {
        toast({
          title: "Missing Information",
          description: "Please provide both Aadhar and PAN numbers for tax exemption.",
          variant: "destructive",
        });
        return;
      }
      
      if (!aadharFile || !panFile) {
        toast({
          title: "Missing Documents",
          description: "Please upload both Aadhar and PAN card documents for tax exemption.",
          variant: "destructive",
        });
        return;
      }
    }

    // Create FormData to handle file uploads
    const formData = new FormData();
    formData.append("userId", userId?.toString() || "");
    formData.append("amount", values.donationAmount);
    formData.append("paymentMethod", values.paymentMethod);
    formData.append("donationPurpose", values.donationPurpose);
    
    // Add custom donation purpose if applicable
    if (values.donationPurpose === "general" && values.customDonationPurpose) {
      formData.append("customDonationPurpose", values.customDonationPurpose);
    }
    
    formData.append("taxExemption", values.taxExemption);
    
    if (values.taxExemption === "yes") {
      formData.append("aadharNumber", values.aadharNumber || "");
      formData.append("panNumber", values.panNumber || "");
      if (aadharFile) formData.append("aadharDoc", aadharFile);
      if (panFile) formData.append("panDoc", panFile);
    }

    // Submit the form
    processPaymentMutation.mutate(formData);
  }

  // Handle quick amount selection
  const handleQuickAmount = (amount: number) => {
    form.setValue("donationAmount", amount.toString());
  };

  // Watch the donationPurpose field to show/hide custom purpose field
  const donationPurpose = form.watch("donationPurpose");
  const showCustomPurpose = donationPurpose === "general";
  
  // Calculate donation amount for summary
  const donationAmount = parseFloat(form.watch("donationAmount")) || 0;

  return (
    <DonationLayout currentStep={2}>
      <div className="mb-6 text-center">
        <div className="w-24 h-24 mx-auto mb-4 rounded-full overflow-hidden border-2 border-primary">
          <img 
            src={swamigalImage} 
            alt="Om Sri Sarguru Palani Swamigal" 
            className="w-full h-full object-cover"
          />
        </div>
        <h2 className="text-xl font-heading font-semibold text-primary-800 mb-2">
          Donation Details
        </h2>
        <p className="text-sm text-gray-600">
          Complete your donation with the following details
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Tax Exemption Section */}
          <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
            <h3 className="text-md font-medium text-gray-800 mb-2">
              Tax Exemption Under 80G
            </h3>
            <p className="text-sm text-gray-600 mb-3">
              Avail tax benefits for your donation under section 80G
            </p>

            <FormField
              control={form.control}
              name="taxExemption"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="space-y-3"
                    >
                      <div className="flex items-center">
                        <RadioGroupItem value="yes" id="taxYes" />
                        <Label htmlFor="taxYes" className="ml-2">
                          Yes, I want to avail tax benefits
                        </Label>
                      </div>
                      <div className="flex items-center">
                        <RadioGroupItem value="no" id="taxNo" />
                        <Label htmlFor="taxNo" className="ml-2">
                          No, I'll skip tax benefits
                        </Label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Tax Documents Section - Conditional */}
          {showTaxDocs && (
            <div className="space-y-4 border-t border-gray-200 pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="aadharNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Aadhar Number*</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="XXXX XXXX XXXX"
                          {...field}
                        />
                      </FormControl>
                      <p className="mt-1 text-xs text-gray-500">
                        Format: 1234 5678 9012
                      </p>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="panNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>PAN Number*</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="ABCDE1234F"
                          {...field}
                        />
                      </FormControl>
                      <p className="mt-1 text-xs text-gray-500">
                        Format: ABCDE1234F
                      </p>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormItem>
                  <FormLabel>Upload Aadhar Card*</FormLabel>
                  <FileInput
                    id="aadharUpload"
                    onFileChange={setAadharFile}
                    value={aadharFile}
                  />
                </FormItem>
                <FormItem>
                  <FormLabel>Upload PAN Card*</FormLabel>
                  <FileInput
                    id="panUpload"
                    onFileChange={setPanFile}
                    value={panFile}
                  />
                </FormItem>
              </div>
            </div>
          )}

          {/* Payment Amount Section */}
          <div className="border-t border-gray-200 pt-4">
            <h3 className="text-lg font-heading font-medium text-gray-800 mb-3">
              Payment Amount
            </h3>

            <div className="space-y-3">
              <FormField
                control={form.control}
                name="donationAmount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Donation Amount (₹)*</FormLabel>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <span className="text-gray-500">₹</span>
                      </div>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="0.00"
                          min="10"
                          className="pl-10"
                          {...field}
                        />
                      </FormControl>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex flex-wrap gap-2">
                {quickDonationAmounts.map((amount) => (
                  <Button
                    key={amount.value}
                    type="button"
                    variant="outline"
                    onClick={() => handleQuickAmount(amount.value)}
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800"
                  >
                    {amount.label}
                  </Button>
                ))}
              </div>
              
              <FormField
                control={form.control}
                name="donationPurpose"
                render={({ field }) => (
                  <FormItem className="mt-4">
                    <FormLabel>Donation Purpose*</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="space-y-3"
                      >
                        <div className="flex items-center">
                          <RadioGroupItem value="medical" id="medical" />
                          <Label htmlFor="medical" className="ml-2">
                            Medical
                          </Label>
                        </div>
                        <div className="flex items-center">
                          <RadioGroupItem value="education" id="education" />
                          <Label htmlFor="education" className="ml-2">
                            Education
                          </Label>
                        </div>
                        <div className="flex items-center">
                          <RadioGroupItem value="food" id="food" />
                          <Label htmlFor="food" className="ml-2">
                            Food
                          </Label>
                        </div>
                        <div className="flex items-center">
                          <RadioGroupItem value="general" id="general" />
                          <Label htmlFor="general" className="ml-2">
                            General
                          </Label>
                        </div>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Custom Donation Purpose - Conditional */}
              {showCustomPurpose && (
                <FormField
                  control={form.control}
                  name="customDonationPurpose"
                  render={({ field }) => (
                    <FormItem className="mt-2">
                      <FormLabel>Specify Purpose</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Enter your donation purpose..."
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </div>
          </div>

          {/* Payment Method Section */}
          <div className="border-t border-gray-200 pt-4">
            <h3 className="text-lg font-heading font-medium text-gray-800 mb-3">
              Payment Method
            </h3>

            <FormField
              control={form.control}
              name="paymentMethod"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="space-y-4"
                    >
                      <div className="flex items-center">
                        <RadioGroupItem value="upi" id="upi" />
                        <Label htmlFor="upi" className="ml-2">
                          UPI
                        </Label>
                      </div>
                      <div className="flex items-center">
                        <RadioGroupItem value="card" id="card" />
                        <Label htmlFor="card" className="ml-2">
                          Credit/Debit Card
                        </Label>
                      </div>
                      <div className="flex items-center">
                        <RadioGroupItem value="netbanking" id="netbanking" />
                        <Label htmlFor="netbanking" className="ml-2">
                          Net Banking
                        </Label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Payment Summary and Submit */}
          <div className="flex flex-col pt-4">
            <div className="bg-gray-50 rounded-lg p-4 border border-gray-200 mb-4">
              <div className="flex justify-between mb-2">
                <span className="text-sm text-gray-600">Donation Amount</span>
                <span className="font-medium">
                  {formatCurrency(donationAmount)}
                </span>
              </div>
              <div className="flex justify-between font-medium">
                <span>Total</span>
                <span className="text-lg">{formatCurrency(donationAmount)}</span>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full py-6 text-lg font-bold bg-green-600 hover:bg-green-700"
              disabled={processPaymentMutation.isPending}
            >
              {processPaymentMutation.isPending ? (
                "Processing..."
              ) : (
                <span className="flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 mr-2"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                    />
                  </svg>
                  PAY NOW
                </span>
              )}
            </Button>

            <p className="mt-4 text-xs text-center text-gray-500">
              By proceeding with the payment, you agree to our{" "}
              <a href="#" className="text-primary">
                Terms of Service
              </a>{" "}
              and{" "}
              <a href="#" className="text-primary">
                Privacy Policy
              </a>
              .
            </p>
          </div>
        </form>
      </Form>
    </DonationLayout>
  );
}
