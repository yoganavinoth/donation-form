import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  mobileNumber: text("mobile_number").notNull().unique(),
  email: text("email").notNull(),
  dob: text("dob").notNull(),
  doorNo: text("door_no").notNull(),
  street: text("street").notNull(),
  taluk: text("taluk").notNull(),
  city: text("city").notNull(),
  village: text("village").notNull(),
  pincode: text("pincode").notNull(),
  state: text("state").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const donations = pgTable("donations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: integer("amount").notNull(),
  paymentMethod: text("payment_method").notNull(),
  transactionId: text("transaction_id").notNull(),
  taxExemption: boolean("tax_exemption").default(false),
  donationPurpose: text("donation_purpose").notNull(),
  aadharNumber: text("aadhar_number"),
  panNumber: text("pan_number"),
  aadharDocPath: text("aadhar_doc_path"),
  panDocPath: text("pan_doc_path"),
  receiptNumber: text("receipt_number").notNull(),
  donationDate: timestamp("donation_date").defaultNow(),
});

export const otpVerifications = pgTable("otp_verifications", {
  id: serial("id").primaryKey(),
  mobileNumber: text("mobile_number").notNull(),
  otp: text("otp").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  verified: boolean("verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true
});

export const insertDonationSchema = createInsertSchema(donations).omit({
  id: true,
  donationDate: true
});

export const insertOtpVerificationSchema = createInsertSchema(otpVerifications).omit({
  id: true,
  verified: true,
  createdAt: true
});

// Validation schemas
export const loginSchema = z.object({
  mobileNumber: z.string()
    .min(1, { message: "Mobile number is required" })
    .transform(val => val.replace(/\D/g, ''))
    .refine(val => val.length === 10, { 
      message: "Mobile number must be 10 digits" 
    }),
});

export const verifyOtpSchema = z.object({
  mobileNumber: z.string()
    .min(1, { message: "Mobile number is required" })
    .transform(val => val.replace(/\D/g, '')),
  otp: z.string()
    .min(1, { message: "OTP is required" })
    .transform(val => val.replace(/\D/g, ''))
    .refine(val => val.length === 6, { 
      message: "OTP must be 6 digits" 
    }),
});

export const registrationSchema = insertUserSchema.extend({
  mobileNumber: z.string()
    .min(1, { message: "Mobile number is required" })
    .transform(val => val.replace(/\D/g, ''))
    .refine(val => val.length === 10, { 
      message: "Mobile number must be 10 digits" 
    }),
  email: z.string().email({ message: "Invalid email address" }),
  pincode: z.string()
    .min(1, { message: "Pincode is required" })
    .transform(val => val.replace(/\D/g, ''))
    .refine(val => val.length === 6, { 
      message: "Pincode must be 6 digits"
    }),
});

export const paymentSchema = z.object({
  userId: z.number(),
  amount: z.number().min(10, { message: "Donation amount must be at least ₹10" }),
  paymentMethod: z.enum(["upi", "card", "netbanking"]),
  taxExemption: z.boolean(),
  donationPurpose: z.enum(["medical", "education", "food", "general"]),
  customDonationPurpose: z.string().optional(),
  aadharNumber: z.string().optional(),
  panNumber: z.string().optional(),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertDonation = z.infer<typeof insertDonationSchema>;
export type Donation = typeof donations.$inferSelect;

export type InsertOtpVerification = z.infer<typeof insertOtpVerificationSchema>;
export type OtpVerification = typeof otpVerifications.$inferSelect;

export type LoginRequest = z.infer<typeof loginSchema>;
export type VerifyOtpRequest = z.infer<typeof verifyOtpSchema>;
export type RegistrationRequest = z.infer<typeof registrationSchema>;
export type PaymentRequest = z.infer<typeof paymentSchema>;
